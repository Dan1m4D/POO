package Aula_2.TP2;


public class Quente {  // Save as "Quente.java"
   public static void main(String[] args) {    
        int cont = 0;
        for(int i = 1; i<=10; i++) {
            cont += i; 
        };
        System.out.println(cont);
    }
}
