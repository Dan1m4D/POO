package Aula_8.Ex1;

public interface KmPercorridosInterface{
    void trajeto(int km);
    int ultimoTrajeto();
    int distanciaTotal();
}
