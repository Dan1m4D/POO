package Aula_3.TP3;


public class yap {
    public static int zRepeat(String s, int j){
        int count = 0;
        for (int i = 0; i < s.length(); ++j){
            char ch = s.charAt(i);
            if (ch == 'Z'){
                count += 1;
        }
        return count;
        
    }
        return count;
}
}
