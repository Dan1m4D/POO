package Aula_3;
import java.util.Scanner;
import java.util.Random;

public class Ex7 {
    public static void main(String[] args) {
        int guess, num, i;
        String s;
        Scanner sc = new Scanner(System.in);
        Random rand = new Random();
        do{
            num = rand.nextInt(101);
            i = 1;
            
            do {
                System.out.println("Guess?");
                guess = sc.nextInt();

                if (guess < num)
                    System.out.println("Too Low!");
                else if (guess > num)
                    System.out.println("Too High!");
                else
                System.out.println("Correct");

                i++;
            }
            while(guess!= num);

            System.out.printf("\nYou tried %s times!", i);
            
            System.out.println("\nSe pretende continuar a jogar prima (S)im");
            s = sc.next();
        }
        while( s == "S" || s == "Sim" );
        sc.close();
    }
}
