package Aula_3;
import java.util.Scanner;

public class Ex3 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.println("N? : ");
        int num = sc.nextInt();

        do{
            System.out.print("Número: ");
            num = sc.nextInt();
            if (num<0){
                System.out.println("Insira um número válido! (Inteiro positivo)");
            }
        }while (num<0);

        boolean flag = false;
        for (int i = 2; i <= num / 2; ++i) {
            if (num % i == 0) {
                flag = true;
                break;
            }
        }
        
        if (flag)
        System.out.println(num + " não é primo");
        else
        System.out.println(num + " é primo");
        
        sc.close();
    }    
}
