package Aula_3;
import java.util.Scanner;

public class Ex5 {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);

        System.out.println("Montante Investido?");
        float MoneyIn = scan.nextFloat();
        if (MoneyIn < 0 || MoneyIn%1000 != 0){
            System.out.println("Montante inválido");
            System.exit(0);
        }

        System.out.println("Taxa de juros Mensal?");
        float TaxaMensal = scan.nextFloat();
        if (TaxaMensal < 0 || TaxaMensal > 5){
            System.out.println("Taxa inválida");
            System.exit(0);
        }

        
        for (int i = 1; i<=12; i++){
            float Inv = MoneyIn * (TaxaMensal/100);
            MoneyIn += Inv;
            System.out.printf("Montante no mes %d : %.02f%n", i, MoneyIn);
        }


        System.out.println("Montante Total = " + MoneyIn);

        scan.close();  
    }
}
