package Aula_3;
import java.util.Scanner;
import java.util.Random;

public class Ex8 {
    public static void main(String[] args) {
    
        double notaP;
        double notaT;
        double notaF;

        double notas[][] = new double [16][3];
        
        Scanner sc = new Scanner(System.in);
        Random rand = new Random();
        for (int i = 0; i < notas.length; i++) {
            notaP = rand.nextDouble(21);
            notaT = rand.nextDouble(21);
            if (notaP < 7.0 || notaT < 7.0 )
            notaF = 66.0;
            else
            notaF = (0.4*notaT) + (0.6*notaP);

            notas[i][0] = notaT;
            notas[i][1] = notaP;
            notas[i][2] = notaF;
        }
        
        System.out.format("%7s %7s %7s \n", "NotaT", "NotaP", "Pauta");

        for (int i = 0; i<notas.length; i++){
            System.out.format("%7.1f %7.1f %7.0f \n", notas[i][0], notas[i][1], notas[i][2]);
        }
        sc.close();
    }
    
}
