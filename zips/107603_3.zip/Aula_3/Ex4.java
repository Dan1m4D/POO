package Aula_3;
import java.util.Scanner;

public class Ex4 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        double med, min, max, Start, n2;
        
        String msg = "A seguir insira um conjunto de numeros reais. O input acaba quando inserir o prineiro numero.";

        System.out.println(msg);
        System.out.println("N? ");
        Start = sc.nextDouble();
        max = Start;
        min = Start;
        med = Start;

        int i = 1;
        do {
            System.out.println("N? ");
            n2 = sc.nextDouble();

            med += n2;
            i+=1;

            if (n2 > max)
            max = n2;
            
            if (n2 < min)
            min = n2;

        }
        while (n2 != Start);
        med = med/i;
        System.out.println("MAX: " + max);
        System.out.println("MIN: " + min);
        System.out.println("MED: " + med);
        System.out.println("NTOTAL: " + i);
        
        sc.close();
    }
}
