package Aula_3;
import java.util.Scanner;

public class Ex2 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.println("N? :");
        long n = sc.nextInt();
        
        System.out.println("-------------START!--------------");

        for (int i = 0; n >= i ; n--){
            System.out.println(n);
        }
        sc.close();
    }
}
