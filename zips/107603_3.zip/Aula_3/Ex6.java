package Aula_3;
import java.util.*;
import java.util.Scanner;

public class Ex6 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int d;

        System.out.println("Insira a data (m/aa)");
        String s = sc.nextLine();
        String [] date = s.split("/");

        int m = Integer.parseInt(date[0]);
        int a = Integer.parseInt(date[1]);

        List<Integer> m31 = Arrays.asList(1,3,5,7,8,10,12);

        if (m == 2){
            if (a%4 == 0 || a%100 == 0 || a%400 == 0)
            d = 28;
            else
            d = 27;
        }
        else{
            if (m31.contains(m))
            d = 31;
            else
            d = 30;
        }

        System.out.printf("O mês %d tem %d dias", m, d);
        sc.close();

    }
}
