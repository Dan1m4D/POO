package teste103234;

import java.util.Collection;


public interface PontosdeInteresse {
    public Collection<String> locais();
}
